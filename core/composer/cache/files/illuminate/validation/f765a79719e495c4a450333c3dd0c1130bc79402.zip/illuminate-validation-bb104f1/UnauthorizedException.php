<?php

namespace Illuminate\Validation;

use RuntimeException;

class UnauthorizedException extends RuntimeException
{
    //
}
