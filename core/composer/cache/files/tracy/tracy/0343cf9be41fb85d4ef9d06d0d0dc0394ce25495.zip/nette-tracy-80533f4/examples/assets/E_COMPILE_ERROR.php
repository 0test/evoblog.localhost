<?php

declare(strict_types=1);

$this = 2;
